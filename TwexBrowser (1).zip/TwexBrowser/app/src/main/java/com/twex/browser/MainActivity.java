package com.twex.browser;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/home.html";
    private static final String DARKWEB = "file:///android_asset/darkweb.html";
    private static final String ASSET_PREFIX = "file:///android_asset";
    private static final String PREFS = "twex_state";
    private static final String TOR_PKG = "org.torproject.torbrowser";
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";
    private static final int FILE_REQ = 1;

    /** One browser tab. The WebView is created lazily when the tab is first shown. */
    private static class Tab {
        WebView web;
        String url;
        String title;

        Tab(String url) {
            this.url = url;
        }
    }

    private final List<Tab> tabs = new ArrayList<>();
    private int current = -1;

    private FrameLayout webContainer;
    private EditText urlBar;
    private ProgressBar progress;
    private FrameLayout fullscreen;
    private View tabsPanel;
    private LinearLayout tabsList;
    private TextView tabsTitle;
    private TextView tabsCount;

    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> filePathCallback;

    private String chromeUA;
    private boolean desktop = false;

    /* ====================================================================== */
    /* lifecycle                                                               */
    /* ====================================================================== */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webContainer = findViewById(R.id.web_container);
        urlBar = findViewById(R.id.url_bar);
        progress = findViewById(R.id.progress);
        fullscreen = findViewById(R.id.fullscreen);
        tabsPanel = findViewById(R.id.tabs_panel);
        tabsList = findViewById(R.id.tabs_list);
        tabsTitle = findViewById(R.id.tabs_title);
        tabsCount = findViewById(R.id.btn_tabs);

        // Same UA as Chrome for Android, without the "wv" WebView markers,
        // so websites do not treat the app as an embedded/limited browser.
        chromeUA = WebSettings.getDefaultUserAgent(this)
                .replace("; wv", "")
                .replace("Version/4.0 ", "");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);

        setupControls();
        restoreTabs();

        Uri data = getIntent().getData();
        if (data != null) {
            tabs.add(new Tab(data.toString()));
            current = tabs.size() - 1;
        }
        if (tabs.isEmpty()) {
            tabs.add(new Tab(HOME));
            current = 0;
        }
        switchTo(Math.max(0, Math.min(current, tabs.size() - 1)));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri data = intent.getData();
        if (data != null) addTab(data.toString());
    }

    @Override
    protected void onPause() {
        // Write cookies (logins) to disk and remember the open tabs.
        CookieManager.getInstance().flush();
        saveTabs();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        CookieManager.getInstance().flush();
        for (Tab t : tabs) {
            if (t.web != null) t.web.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (tabsPanel.getVisibility() == View.VISIBLE) {
            hideTabs();
        } else if (customView != null) {
            hideCustomView();
        } else if (cur() != null && cur().web != null && cur().web.canGoBack()) {
            cur().web.goBack();
        } else if (tabs.size() > 1) {
            closeTab(current);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ && filePathCallback != null) {
            filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /* ====================================================================== */
    /* tabs                                                                    */
    /* ====================================================================== */

    private Tab cur() {
        return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null;
    }

    private void addTab(String url) {
        tabs.add(new Tab(url));
        switchTo(tabs.size() - 1);
    }

    private void switchTo(int index) {
        current = index;
        Tab t = tabs.get(index);
        ensureWeb(t);
        for (Tab other : tabs) {
            if (other.web != null) other.web.setVisibility(other == t ? View.VISIBLE : View.GONE);
        }
        progress.setVisibility(View.GONE);
        t.web.requestFocus();
        updateChrome();
    }

    private void closeTab(int index) {
        Tab t = tabs.remove(index);
        if (t.web != null) {
            webContainer.removeView(t.web);
            t.web.destroy();
        }
        if (tabs.isEmpty()) {
            addTab(HOME);
            return;
        }
        int next;
        if (index < current) next = current - 1;
        else if (index == current) next = Math.min(index, tabs.size() - 1);
        else next = current;
        switchTo(next);
    }

    private void ensureWeb(Tab t) {
        if (t.web != null) return;
        t.web = createWebView(t);
        if (t.url != null) t.web.loadUrl(t.url);
    }

    private void updateChrome() {
        Tab t = cur();
        if (t == null) return;
        if (!urlBar.hasFocus()) urlBar.setText(displayUrl(t.url));
        tabsCount.setText(String.valueOf(tabs.size()));
        if (tabsPanel.getVisibility() == View.VISIBLE) refreshTabsPanel();
    }

    private static String displayUrl(String url) {
        if (url == null || url.startsWith(ASSET_PREFIX)) return "";
        return url;
    }

    private String titleOf(Tab t) {
        if (t.url == null) return "تبويب جديد";
        if (t.url.startsWith(HOME)) return "الصفحة الرئيسية";
        if (!TextUtils.isEmpty(t.title) && !t.title.startsWith("file:")) return t.title;
        Uri u = Uri.parse(t.url);
        return u.getHost() != null ? u.getHost() : t.url;
    }

    /* ---- tabs panel ---- */

    private void showTabs() {
        refreshTabsPanel();
        tabsPanel.setVisibility(View.VISIBLE);
    }

    private void hideTabs() {
        tabsPanel.setVisibility(View.GONE);
    }

    private void refreshTabsPanel() {
        tabsList.removeAllViews();
        tabsTitle.setText("التبويبات (" + tabs.size() + ")");
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(i == current ? R.drawable.bg_tab_on : R.drawable.bg_tab);
            row.setPadding(dp(14), dp(12), dp(6), dp(12));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(8);
            row.setLayoutParams(rowLp);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView title = new TextView(this);
            title.setText(titleOf(t));
            title.setTextColor(getColor(R.color.ink));
            title.setTextSize(15);
            title.setSingleLine(true);
            title.setEllipsize(TextUtils.TruncateAt.END);

            TextView sub = new TextView(this);
            sub.setText(displayUrl(t.url));
            sub.setTextColor(getColor(R.color.muted));
            sub.setTextSize(12);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.END);

            col.addView(title);
            col.addView(sub);

            TextView close = new TextView(this);
            close.setText("✕");
            close.setTextColor(getColor(R.color.muted));
            close.setTextSize(18);
            close.setGravity(Gravity.CENTER);
            close.setPadding(dp(14), dp(8), dp(14), dp(8));
            close.setOnClickListener(v -> {
                closeTab(idx);
                if (tabsPanel.getVisibility() == View.VISIBLE) refreshTabsPanel();
            });

            row.addView(col);
            row.addView(close);
            row.setOnClickListener(v -> {
                switchTo(idx);
                hideTabs();
            });
            tabsList.addView(row);
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    /* ---- persistence ---- */

    private void saveTabs() {
        try {
            JSONArray arr = new JSONArray();
            int saveCur = 0;
            for (int i = 0; i < tabs.size(); i++) {
                Tab t = tabs.get(i);
                if (t.url == null || t.url.startsWith("data:")) continue;
                if (i == current) saveCur = arr.length();
                arr.put(t.url);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("tabs", arr.toString())
                    .putInt("current", saveCur)
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private void restoreTabs() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            String s = p.getString("tabs", null);
            if (s == null) return;
            JSONArray arr = new JSONArray(s);
            for (int i = 0; i < arr.length() && i < 30; i++) tabs.add(new Tab(arr.getString(i)));
            current = Math.min(p.getInt("current", 0), tabs.size() - 1);
        } catch (Exception ignored) {
            tabs.clear();
        }
    }

    /* ====================================================================== */
    /* WebView                                                                 */
    /* ====================================================================== */

    private WebView createWebView(final Tab tab) {
        final WebView wv = new WebView(this);
        wv.setBackgroundColor(0xFF06110C);
        webContainer.addView(wv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        wv.setVisibility(View.GONE);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(desktop ? DESKTOP_UA : chromeUA);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);

        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        if (Build.VERSION.SDK_INT >= 26) {
            // lets the phone's autofill service (Google, Bitwarden...) save and fill passwords
            wv.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_YES);
        }

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                String host = request.getUrl().getHost();

                if (u.startsWith("twex:")) {
                    String pkg = request.getUrl().getQueryParameter("pkg");
                    if (pkg != null) launchOrInstall(pkg);
                    return true;
                }
                if (host != null && host.endsWith(".onion")) {
                    openInTor(u);
                    return true;
                }
                if (u.startsWith("http:") || u.startsWith("https:") || u.startsWith("file:")
                        || u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:")) {
                    return false;
                }
                try {
                    Intent i = u.startsWith("intent:")
                            ? Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, Uri.parse(u));
                    startActivity(i);
                } catch (Exception ignored) {
                    toast("ما لقيت تطبيق يفتح الرابط ده");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                tab.url = url;
                if (tab == cur() && !urlBar.hasFocus()) urlBar.setText(displayUrl(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                tab.url = url;
                if (tab == cur() && !urlBar.hasFocus()) urlBar.setText(displayUrl(url));
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                String failing = request.getUrl().toString();
                String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;background:#06110c;color:#e9f6ee;text-align:center;padding:48px 20px;direction:rtl'>"
                        + "<h2 style='color:#34e39a'>تعذر فتح الصفحة</h2>"
                        + "<p>" + TextUtils.htmlEncode(String.valueOf(error.getDescription())) + "</p>"
                        + "<p style='direction:ltr;color:#84a898;word-break:break-all'>" + TextUtils.htmlEncode(failing) + "</p>"
                        + "<p>تأكد من الانترنت ثم اضغط تحديث ⟳</p></body></html>";
                view.loadDataWithBaseURL(failing, html, "text/html", "UTF-8", failing);
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (tab != cur()) return;
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                tab.title = title;
                if (tabsPanel.getVisibility() == View.VISIBLE) refreshTabsPanel();
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false;
                Tab popup = new Tab(null);
                popup.web = createWebView(popup);
                tabs.add(popup);
                switchTo(tabs.size() - 1);
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup.web);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onCloseWindow(WebView window) {
                for (int i = 0; i < tabs.size(); i++) {
                    if (tabs.get(i).web == window) {
                        final int idx = i;
                        webContainer.post(() -> {
                            if (idx < tabs.size()) closeTab(idx);
                        });
                        return;
                    }
                }
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = callback;
                fullscreen.addView(view);
                fullscreen.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        wv.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                startDownload(url, userAgent, contentDisposition, mimeType));

        return wv;
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreen.removeView(customView);
        fullscreen.setVisibility(View.GONE);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimeType) {
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setMimeType(mimeType);
            req.addRequestHeader("User-Agent", userAgent);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.setTitle(name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= 29) {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            } else {
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
            }
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            toast("بدأ التحميل: " + name);
        } catch (Exception e) {
            toast("ما قدرت أبدأ التحميل");
        }
    }

    /* ====================================================================== */
    /* controls                                                                */
    /* ====================================================================== */

    private void setupControls() {
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });

        findViewById(R.id.btn_back).setOnClickListener(v -> {
            Tab t = cur();
            if (t != null && t.web != null && t.web.canGoBack()) t.web.goBack();
        });
        findViewById(R.id.btn_fwd).setOnClickListener(v -> {
            Tab t = cur();
            if (t != null && t.web != null && t.web.canGoForward()) t.web.goForward();
        });
        findViewById(R.id.btn_home).setOnClickListener(v -> loadInCurrent(HOME));
        findViewById(R.id.btn_reload).setOnClickListener(v -> {
            Tab t = cur();
            if (t != null && t.web != null) t.web.reload();
        });
        tabsCount.setOnClickListener(v -> showTabs());
        findViewById(R.id.btn_menu).setOnClickListener(this::showMenu);
        findViewById(R.id.btn_new_tab).setOnClickListener(v -> {
            addTab(HOME);
            hideTabs();
        });
        findViewById(R.id.btn_close_panel).setOnClickListener(v -> hideTabs());
    }

    private void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "تبويب جديد");
        m.getMenu().add(0, 2, 1, "متصفحات الدارك ويب");
        m.getMenu().add(0, 3, 2, "وضع الكمبيوتر").setCheckable(true).setChecked(desktop);
        m.getMenu().add(0, 4, 3, "فتح في متصفح آخر");
        m.getMenu().add(0, 5, 4, "مسح الكاش والكوكيز (بيطلعك من المواقع)");
        m.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    addTab(HOME);
                    return true;
                case 2:
                    loadInCurrent(DARKWEB);
                    return true;
                case 3:
                    toggleDesktop();
                    return true;
                case 4:
                    openExternal();
                    return true;
                case 5:
                    clearData();
                    return true;
                default:
                    return false;
            }
        });
        m.show();
    }

    private void loadInCurrent(String url) {
        Tab t = cur();
        if (t == null) return;
        ensureWeb(t);
        t.web.loadUrl(url);
    }

    private void toggleDesktop() {
        desktop = !desktop;
        for (Tab t : tabs) {
            if (t.web == null) continue;
            WebSettings s = t.web.getSettings();
            s.setUserAgentString(desktop ? DESKTOP_UA : chromeUA);
            s.setUseWideViewPort(desktop);
            s.setLoadWithOverviewMode(desktop);
        }
        Tab t = cur();
        if (t != null && t.web != null) t.web.reload();
    }

    private void openExternal() {
        Tab t = cur();
        String u = (t != null && t.web != null) ? t.web.getUrl() : null;
        if (u != null && u.startsWith("http")) {
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW, Uri.parse(u)), "فتح بواسطة"));
        }
    }

    private void clearData() {
        for (Tab t : tabs) {
            if (t.web != null) {
                t.web.clearCache(true);
                t.web.clearHistory();
            }
        }
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        toast("تم المسح");
    }

    /* ---- dark web helpers ---- */

    private void launchOrInstall(String pkg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        toast("التطبيق مش مثبت عندك، بفتح لك صفحة تحميله");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg)));
        } catch (ActivityNotFoundException e) {
            loadInCurrent("https://play.google.com/store/apps/details?id=" + pkg);
        }
    }

    private void openInTor(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url.replaceFirst("^https://", "http://")));
            i.setPackage(TOR_PKG);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("روابط .onion بتفتح بس بمتصفح Tor");
            loadInCurrent(DARKWEB);
        }
    }

    /* ====================================================================== */
    /* helpers                                                                 */
    /* ====================================================================== */

    private void go(String text) {
        String u = normalize(text);
        if (u.isEmpty()) return;

        urlBar.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);

        String host = Uri.parse(u).getHost();
        if (host != null && host.endsWith(".onion")) {
            openInTor(u);
            return;
        }
        loadInCurrent(u);
    }

    private String normalize(String in) {
        String t = in == null ? "" : in.trim();
        if (t.isEmpty()) return "";
        if (t.matches("(?i)^https?://.+")) return t;
        if (t.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?([/?#].*)?$")) return "http://" + t;
        if (t.matches("(?i)^[^\\s]+\\.[a-z]{2,}([/?#:].*)?$") || t.startsWith("localhost")) {
            return "https://" + t;
        }
        return "https://www.google.com/search?q=" + Uri.encode(t);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
